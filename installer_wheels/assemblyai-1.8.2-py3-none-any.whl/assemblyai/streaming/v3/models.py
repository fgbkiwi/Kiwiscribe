from datetime import datetime
from enum import Enum
from typing import Any, List, Literal, Optional, Union

try:
    # pydantic v2 import
    from pydantic import BaseModel, Field, model_validator

    pydantic_v2 = True
except ImportError:
    # pydantic v1 import (fallback for Python < 3.14)
    from pydantic import BaseModel, Field, root_validator

    pydantic_v2 = False


class LLMGatewayMessage(BaseModel):
    role: str
    content: str


class LLMGatewayConfig(BaseModel):
    model: str
    messages: List["LLMGatewayMessage"]
    max_tokens: int


class Word(BaseModel):
    start: int
    end: int
    confidence: float
    text: str
    word_is_final: bool
    speaker: Optional[str] = None


class TurnEvent(BaseModel):
    type: Literal["Turn"]
    turn_order: int
    turn_is_formatted: bool
    end_of_turn: bool
    transcript: str
    end_of_turn_confidence: float
    words: List[Word]
    language_code: Optional[str] = None
    language_confidence: Optional[float] = None
    speaker_label: Optional[str] = None


class SessionConfiguration(BaseModel):
    # `mode` stays a plain str so a new server-side mode value can't fail
    # validation and drop the whole BeginEvent.
    model: Optional[str] = None
    mode: Optional[str] = None
    api_version: Optional[str] = None


class BeginEvent(BaseModel):
    type: Literal["Begin"] = "Begin"
    id: str
    expires_at: datetime
    configuration: Optional[SessionConfiguration] = None


class TerminationEvent(BaseModel):
    type: Literal["Termination"] = "Termination"
    audio_duration_seconds: Optional[int] = None
    session_duration_seconds: Optional[int] = None


class SpeechStartedEvent(BaseModel):
    type: Literal["SpeechStarted"] = "SpeechStarted"
    timestamp: int


class ErrorEvent(BaseModel):
    type: Literal["Error"] = "Error"
    error_code: Optional[int] = None
    error: str


class WarningEvent(BaseModel):
    type: Literal["Warning"] = "Warning"
    warning_code: int
    warning: str


class HeartbeatEvent(BaseModel):
    type: Literal["Heartbeat"] = "Heartbeat"
    total_audio_received_ms: int
    total_duration_ms: int
    # Unclamped processing speed ratio; may exceed 1.0.
    realtime_factor: float
    # Highest per-frame speech probability in the interval, range 0-1.
    max_speech_probability: float = 0.0


class SilenceEvent(BaseModel):
    """A stretch of audio the server transcribed no speech in.

    Emitted roughly once per second while no speech is being transcribed, and
    only when the session opted in with `acknowledge_silence` (U3Pro only).
    """

    type: Literal["Silence"] = "Silence"
    # Session audio positions, on the same clock as word start/end timestamps.
    start_ms: int
    # A worker reconnect replays ~500 ms of audio, so a range can overlap
    # audio already reported as speech; trim with a running max.
    end_ms: int


class LLMGatewayResponseEvent(BaseModel):
    type: Literal["LLMGatewayResponse"] = "LLMGatewayResponse"
    turn_order: int
    transcript: str
    data: Any


class SpeakerRevisionItem(BaseModel):
    """A single Turn whose speaker labels were revised by reclustering.

    Match by `turn_order` against the original Turn; replace its per-word
    speaker assignments (and the turn-level `speaker_label`) with these. Text
    and word timestamps are unchanged from the original Turn.
    """

    turn_order: int
    speaker_label: Optional[str] = None
    words: List[Word] = []


class SpeakerRevisionEvent(BaseModel):
    """Server-side correction to previously-emitted Turns' speaker labels.

    Emitted once per offline-recluster resolve. `revisions` carries one entry
    per earlier Turn whose label actually changed (unchanged turns are
    omitted). Apply each entry by matching its `turn_order`.
    """

    type: Literal["SpeakerRevision"] = "SpeakerRevision"
    revisions: List[SpeakerRevisionItem] = []


EventMessage = Union[
    BeginEvent,
    TerminationEvent,
    TurnEvent,
    SpeechStartedEvent,
    ErrorEvent,
    WarningEvent,
    HeartbeatEvent,
    SilenceEvent,
    LLMGatewayResponseEvent,
    SpeakerRevisionEvent,
]


class TerminateSession(BaseModel):
    type: Literal["Terminate"] = "Terminate"


class ForceEndpoint(BaseModel):
    type: Literal["ForceEndpoint"] = "ForceEndpoint"


class KeepAlive(BaseModel):
    type: Literal["KeepAlive"] = "KeepAlive"


class RealTimeSessionParameters(BaseModel):
    end_of_turn_confidence_threshold: Optional[float] = None
    min_end_of_turn_silence_when_confident: Optional[int] = (
        None  # Deprecated: Use min_turn_silence instead
    )
    min_turn_silence: Optional[int] = None
    max_turn_silence: Optional[int] = None
    vad_threshold: Optional[float] = None
    format_turns: Optional[bool] = None
    keyterms_prompt: Optional[List[str]] = None
    filter_profanity: Optional[bool] = None
    prompt: Optional[str] = None
    agent_context: Optional[str] = None
    interruption_delay: Optional[int] = None
    turn_left_pad_ms: Optional[int] = None
    language_codes: Optional[List[str]] = None
    session_heartbeat: Optional[bool] = None
    # Opt in to Silence messages during silence (U3Pro only). When True, the
    # server emits a Silence message roughly once per second while no speech is
    # being transcribed, carrying `start_ms` and `end_ms`, the audio positions
    # the silent stretch spans. When unset/False, no Silence messages are sent.
    acknowledge_silence: Optional[bool] = None


# Alias: the former name for `RealTimeSessionParameters`, bound to the same object.
StreamingSessionParameters = RealTimeSessionParameters


class Encoding(str, Enum):
    pcm_s16le = "pcm_s16le"
    pcm_mulaw = "pcm_mulaw"
    # Raw Opus packets, one packet per binary WS message. `sample_rate` may be
    # omitted — the Opus stream is self-describing and the server ignores it.
    opus = "opus"
    # Ogg-encapsulated Opus byte stream (ffmpeg, gstreamer, opusenc, browser
    # MediaRecorder output). `sample_rate` may be omitted — the Opus stream is
    # self-describing and the server ignores it.
    ogg_opus = "ogg_opus"
    # AAC in an ADTS byte stream. `sample_rate` may be omitted — the ADTS
    # headers are self-describing and the server ignores it.
    aac = "aac"

    def __str__(self):
        return self.value


class SpeechModel(str, Enum):
    universal_streaming_multilingual = "universal-streaming-multilingual"
    universal_streaming_english = "universal-streaming-english"
    u3_rt_pro = "u3-rt-pro"
    u3_rt_pro_beta_1 = "u3-rt-pro-beta-1"
    whisper_rt = "whisper-rt"
    universal_3_5_pro = "universal-3-5-pro"
    universal_3_6 = "universal-3-6"
    universal_3_6_pro = "universal-3-6-pro"
    u3_pro = "u3-pro"  # Deprecated: Use u3_rt_pro instead

    def __str__(self):
        return self.value


class StreamingDomain(str, Enum):
    medical = "medical-v1"

    def __str__(self):
        return self.value


class NoiseSuppressionModel(str, Enum):
    near_field = "near-field"
    far_field = "far-field"

    def __str__(self):
        return self.value


class StreamingMode(str, Enum):
    max_accuracy = "max_accuracy"
    min_latency = "min_latency"
    balanced = "balanced"

    def __str__(self):
        return self.value


class StreamingPiiSubstitution(str, Enum):
    hash = "hash"
    entity_name = "entity_name"

    def __str__(self):
        return self.value


class StreamingPiiPolicy(str, Enum):
    account_number = "account_number"
    banking_information = "banking_information"
    blood_type = "blood_type"
    credit_card_number = "credit_card_number"
    credit_card_expiration = "credit_card_expiration"
    credit_card_cvv = "credit_card_cvv"
    date = "date"
    date_interval = "date_interval"
    date_of_birth = "date_of_birth"
    drivers_license = "drivers_license"
    drug = "drug"
    duration = "duration"
    email_address = "email_address"
    event = "event"
    filename = "filename"
    gender_sexuality = "gender_sexuality"
    gender = "gender"
    healthcare_number = "healthcare_number"
    injury = "injury"
    ip_address = "ip_address"
    language = "language"
    location = "location"
    marital_status = "marital_status"
    medical_condition = "medical_condition"
    medical_process = "medical_process"
    money_amount = "money_amount"
    nationality = "nationality"
    number_sequence = "number_sequence"
    passport_number = "passport_number"
    password = "password"
    person_age = "person_age"
    person_name = "person_name"
    phone_number = "phone_number"
    physical_attribute = "physical_attribute"
    political_affiliation = "political_affiliation"
    occupation = "occupation"
    organization = "organization"
    organization_medical_facility = "organization_medical_facility"
    religion = "religion"
    sexuality = "sexuality"
    statistics = "statistics"
    time = "time"
    url = "url"
    us_social_security_number = "us_social_security_number"
    username = "username"
    vehicle_id = "vehicle_id"
    zodiac_sign = "zodiac_sign"

    def __str__(self):
        return self.value


class RealTimeParameters(RealTimeSessionParameters):
    # Required for PCM encodings. May be omitted for Opus encodings
    # (opus, ogg_opus) — the stream is self-describing and the server
    # ignores the value.
    sample_rate: Optional[int] = None
    encoding: Optional[Encoding] = None
    speech_model: Optional[SpeechModel] = None
    # Deprecated: use language_codes instead (pass a single-element list, e.g.
    # ["es"], for the same behavior). Still supported for backward compatibility.
    language_code: Optional[str] = None
    language_detection: Optional[bool] = None
    domain: Optional[StreamingDomain] = None
    inactivity_timeout: Optional[int] = None
    webhook_url: Optional[str] = None
    webhook_auth_header_name: Optional[str] = None
    webhook_auth_header_value: Optional[str] = None
    llm_gateway: Optional[LLMGatewayConfig] = None
    speaker_labels: Optional[bool] = None
    speaker_labels_revision_interval_ms: Optional[int] = Field(None, ge=0)
    max_speakers: Optional[int] = None
    voice_focus: Optional[NoiseSuppressionModel] = None
    voice_focus_threshold: Optional[float] = None
    # Deprecated: use voice_focus / voice_focus_threshold instead.
    noise_suppression_model: Optional[NoiseSuppressionModel] = None
    noise_suppression_threshold: Optional[float] = None
    continuous_partials: Optional[bool] = None
    customer_support_audio_capture: Optional[bool] = None
    include_partial_turns: Optional[bool] = None
    redact_pii: Optional[bool] = None
    redact_pii_policies: Optional[List[StreamingPiiPolicy]] = None
    redact_pii_sub: Optional[StreamingPiiSubstitution] = None
    mode: Optional[StreamingMode] = None

    if pydantic_v2:

        @model_validator(mode="after")
        def _require_sample_rate(self):
            if self.sample_rate is None and self.encoding not in (
                Encoding.opus,
                Encoding.ogg_opus,
                Encoding.aac,
            ):
                raise ValueError(
                    "sample_rate is required; it may only be omitted when "
                    "encoding is 'opus', 'ogg_opus', or 'aac' (these streams "
                    "are self-describing)."
                )
            return self

    else:

        @root_validator(skip_on_failure=True)
        def _require_sample_rate(cls, values):
            if values.get("sample_rate") is None and values.get("encoding") not in (
                Encoding.opus,
                Encoding.ogg_opus,
                Encoding.aac,
            ):
                raise ValueError(
                    "sample_rate is required; it may only be omitted when "
                    "encoding is 'opus', 'ogg_opus', or 'aac' (these streams "
                    "are self-describing)."
                )
            return values


# Alias: the former name for `RealTimeParameters`, bound to the same object.
StreamingParameters = RealTimeParameters


class UpdateConfiguration(RealTimeSessionParameters):
    type: Literal["UpdateConfiguration"] = "UpdateConfiguration"


OperationMessage = Union[
    bytes,
    TerminateSession,
    ForceEndpoint,
    KeepAlive,
    UpdateConfiguration,
]


class RealTimeTranscriberOptions(BaseModel):
    api_host: str = "streaming.assemblyai.com"
    api_key: Optional[str] = None
    token: Optional[str] = None
    # Seconds to wait for the WebSocket handshake to complete before treating
    # the attempt as failed. Must be positive.
    connect_timeout: float = Field(default=1.0, gt=0)
    # Additional handshake attempts after the first one fails on a transient
    # error (timeout, network drop). 0 disables retries. HTTP-level rejections
    # (auth, quota, bad request) are never retried. Must be non-negative.
    max_connection_retries: int = Field(default=2, ge=0)
    # Seconds to wait between handshake attempts. Must be non-negative.
    connection_retry_delay: float = Field(default=0.5, ge=0)
    # Seconds disconnect(terminate=True) waits for the server's
    # TerminationEvent (and any final Turn) before tearing down. Must be non-negative.
    terminate_timeout: float = Field(default=5.0, ge=0)


# Alias: the former name for `RealTimeTranscriberOptions`, bound to the same object.
StreamingClientOptions = RealTimeTranscriberOptions


class RealTimeError(Exception):
    def __init__(self, message: str, code: Optional[int] = None):
        super().__init__(message)
        self.code = code


# Alias: the former name for `RealTimeError`, bound to the same object.
StreamingError = RealTimeError


RealTimeErrorCodes = {
    3005: "Server error",
    3006: "Input validation error",
    3007: "Audio chunk duration violation",
    3008: "Session expired: maximum session duration exceeded",
    3009: "Too many concurrent sessions",
    4000: "Sample rate must be a positive integer",
    4001: "Not Authorized",
    4002: "Insufficient Funds",
    4003: """This feature is paid-only and requires you to add a credit card.
    Please visit https://app.assemblyai.com/ to add a credit card to your account""",
    4004: "Session Not Found",
    4008: "Session Expired",
    4010: "Session Previously Closed",
    4029: "Client sent audio too fast",
    4030: "Session is handled by another websocket",
    4031: "Session idle for too long",
    4032: "Audio duration is too short",
    4033: "Audio duration is too long",
    4034: "Audio too small to transcode",
    4100: "Endpoint received invalid JSON",
    4101: "Endpoint received a message with an invalid schema",
    4102: "This account has exceeded the number of allowed streams",
    4103: "The session has been reconnected. This websocket is no longer valid.",
    1013: "Temporary server condition forced blocking client's request",
}

# Alias: the former name for `RealTimeErrorCodes`, bound to the same object.
StreamingErrorCodes = RealTimeErrorCodes


class RealTimeEvents(Enum):
    Begin = "Begin"
    Termination = "Termination"
    Turn = "Turn"
    SpeechStarted = "SpeechStarted"
    Error = "Error"
    Warning = "Warning"
    Heartbeat = "Heartbeat"
    Silence = "Silence"
    LLMGatewayResponse = "LLMGatewayResponse"
    SpeakerRevision = "SpeakerRevision"


# Alias: the former name for `RealTimeEvents`, bound to the same object.
StreamingEvents = RealTimeEvents
